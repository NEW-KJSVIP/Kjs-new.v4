from telethon import TelegramClient
import datetime as DT
import requests, time, os, subprocess, re, sqlite3, sys, random, base64, json, math
import logging

logging.basicConfig(level=logging.INFO)
uptime = DT.datetime.now()

# ---------- Load Config Bot Publik ----------
exec(open("/usr/bin/kyt-public/var.txt", "r").read())

# ---------- Inisialisasi Bot Publik ----------
bot = TelegramClient("ddsdswl-public", "6", "eb06d4abfb49dc3eeb1aeb98ae0f581e").start(bot_token=BOT_TOKEN)

# ---------- Cek / Buat Database ----------
db_path = "/usr/bin/kyt-public/database.db"
try:
    open(db_path)
except FileNotFoundError:
    x = sqlite3.connect(db_path)
    c = x.cursor()
    c.execute("CREATE TABLE admin (user_id)")
    c.execute("INSERT INTO admin (user_id) VALUES (?)", (ADMIN,))
    x.commit()
    x.close()

# ---------- Fungsi Database ----------
def get_db():
    x = sqlite3.connect(db_path)
    x.row_factory = sqlite3.Row
    return x

# ---------- Validasi Admin ----------
def valid(user_id):
    db = get_db()
    x = db.execute("SELECT user_id FROM admin").fetchall()
    admins = [v[0] for v in x]
    return user_id in admins  # True jika ada, False jika tidak

# ---------- Fungsi Convert Size ----------
def convert_size(size_bytes):
    if size_bytes == 0:
        return "0B"
    size_name = ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
    i = int(math.floor(math.log(size_bytes, 1024)))
    p = math.pow(1024, i)
    s = round(size_bytes / p, 2)
    return f"{s} {size_name[i]}"
