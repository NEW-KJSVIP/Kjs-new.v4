from kyt_public import *
from telethon import events, Button
import subprocess

@bot.on(events.NewMessage(pattern=r"(?:.start|/start)$"))
@bot.on(events.CallbackQuery(data=b'start'))
async def start_public(event):
    inline = [
        [Button.inline("PANEL CREATE ACCOUNT","menu")],
        [Button.url("PRIVATE MESSAGE","https://t.me/newbie_store24"),
         Button.url("ORDER SCRIPT","https://whatsapp.nevpn.site")]
    ]
    sender = await event.get_sender()
    if not valid(str(sender.id)):
        try:
            await event.answer("Akses Ditolak", alert=True)
        except:
            await event.reply("Akses Ditolak")
        return

    # Ambil statistik sama seperti bot admin
    ssh = subprocess.getoutput("cat /etc/ssh/.ssh.db | grep '###' | wc -l")
    vms = subprocess.getoutput("cat /etc/vmess/.vmess.db | grep '###' | wc -l")
    vls = subprocess.getoutput("cat /etc/vless/.vless.db | grep '###' | wc -l")
    trj = subprocess.getoutput("cat /etc/trojan/.trojan.db | grep '###' | wc -l")
    namaos = subprocess.getoutput("cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'").replace('"','')
    ipsaya = subprocess.getoutput("curl -s ipv4.icanhazip.com")
    city = subprocess.getoutput("cat /etc/xray/city")

    msg = f"""```
╭━〔 🐾🕊️ PREMIUM PANEL PUBLIC 🕊️🐾 〕
┃  • Status Server  : ✅ Online
┃  • DOMAIN         : {DOMAIN}
┃  • IP VPS         : {ipsaya}
┃  • OS             : {namaos}
┃  • CITY           : {city}
┃━━━━━━━〔 Statistik Akun 〕
┃  🚀 SSH OVPN    : {ssh}
┃  🎭 XRAY VMESS  : {vms}
┃  🗼 XRAY VLESS  : {vls}
┃  🎯 XRAY TROJAN : {trj}
┃━━━━━━━〔 Admin 〕
┃  @KJS_STORE
╰━━━━━━━━━━━━━━━━━╯
```"""

    x = await event.edit(msg, buttons=inline)
    if not x:
        await event.reply(msg, buttons=inline)
