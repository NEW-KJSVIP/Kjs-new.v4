from kyt_public import *
from telethon import events, Button
import subprocess, time, requests

# ---------- REBOOT SERVER PUBLIK ----------
@bot.on(events.CallbackQuery(data=b'reboot'))
async def reboot_public(event):
    async def reboot_(event):
        cmd = f'reboot'
        await event.edit("Processing...")
        time.sleep(1)
        await event.edit("`Processing Restart Service Server...`")
        subprocess.check_output(cmd, shell=True)
        await event.edit(f"**» REBOOT SERVER PUBLIC DONE**", buttons=[[Button.inline("‹ Main Menu ›","menu")]])

    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await reboot_(event)
    else:
        await event.answer("Access Denied", alert=True)

# ---------- RESTART SERVICE PUBLIK ----------
@bot.on(events.CallbackQuery(data=b'resx'))
async def restart_service_public(event):
    async def resx_(event):
        cmd = 'systemctl restart kyt-public'
        subprocess.check_output(cmd, shell=True)
        await event.edit("**Restarting Public Service Done**", buttons=[[Button.inline("‹ Main Menu ›","menu")]])

    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await resx_(event)
    else:
        await event.answer("Access Denied", alert=True)

# ---------- SPEEDTEST PUBLIK ----------
@bot.on(events.CallbackQuery(data=b'speedtest'))
async def speedtest_public(event):
    async def speedtest_(event):
        cmd = 'speedtest-cli --share'
        result = subprocess.check_output(cmd, shell=True).decode("utf-8")
        await event.respond(f"```{result}```", buttons=[[Button.inline("‹ Main Menu ›","menu")]])

    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await speedtest_(event)
    else:
        await event.answer("Access Denied", alert=True)

# ---------- BACKUP & RESTORE PUBLIK ----------
@bot.on(events.CallbackQuery(data=b'backer'))
async def backers_public(event):
    async def backers_(event):
        inline = [
            [Button.inline(" BACKUP","backup"), Button.inline(" RESTORE","restore")],
            [Button.inline("‹ Main Menu ›","menu")]
        ]
        try:
            z = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        except:
            z = {"country":"Unknown","isp":"Unknown"}
        msg = f"""
╭━━━〔 🐾🕊️ PUBLIC PANEL MENU 🕊️🐾 〕
┃
┃  🌐 **Hostname/IP** : `{DOMAIN}`
┃  🏢 **ISP**         : `{z["isp"]}`
┃  🌍 **Country**     : `{z["country"]}`
╰━━━━━━━━━━━━━━━━━╯
"""
        await event.edit(msg, buttons=inline)

    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await backers_(event)
    else:
        await event.answer("Access Denied", alert=True)

# ---------- SETTINGS PUBLIK ----------
@bot.on(events.CallbackQuery(data=b'setting'))
async def settings_public(event):
    async def settings_(event):
        inline = [
            [Button.inline(" SPEEDTEST","speedtest"), Button.inline(" BACKUP & RESTORE","backer")],
            [Button.inline(" REBOOT SERVER","reboot"), Button.inline(" RESTART SERVICE","resx")],
            [Button.inline("‹ Main Menu ›","menu")]
        ]
        try:
            z = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        except:
            z = {"country":"Unknown","isp":"Unknown"}
        msg = f"""
╭━━━〔 🐾🕊️ PUBLIC PANEL MENU 🕊️🐾 〕
┃
┃  🌐 **Hostname/IP** : `{DOMAIN}`
┃  🏢 **ISP**         : `{z["isp"]}`
┃  🌍 **Country**     : `{z["country"]}`
╰━━━━━━━━━━━━━━━━━╯
"""
        await event.edit(msg, buttons=inline)

    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await settings_(event)
    else:
        await event.answer("Access Denied", alert=True)
