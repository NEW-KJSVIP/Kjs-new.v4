from kyt import *
import subprocess

# Listener untuk .menu, /menu, dan .mets
@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu|.mets)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    inline = [
        [Button.inline(" SSH OVPN MANAGER ", "ssh")],
        [Button.inline(" VMESS MANAGER ", "vmess"),
         Button.inline(" VLESS MANAGER ", "vless")],
        [Button.inline(" TROJAN MANAGER ", "trojan"),
         Button.inline(" SHDWSK MANAGER ", "shadowsocks")],
        [Button.inline(" CHECK VPS INFO ", "info"),
         Button.inline(" OTHER SETTING ", "setting")],
        [Button.inline(" ‹ Back Menu › ", "start")]
    ]

    # Ambil statistik server (pakai getoutput biar lebih aman)
    ssh = subprocess.getoutput("grep -c 'home' /etc/passwd || echo 0")
    vms = subprocess.getoutput("grep -c '###' /etc/vmess/.vmess.db 2>/dev/null || echo 0")
    vls = subprocess.getoutput("grep -c '###' /etc/vless/.vless.db 2>/dev/null || echo 0")
    trj = subprocess.getoutput("grep -c '###' /etc/trojan/.trojan.db 2>/dev/null || echo 0")
    namaos = subprocess.getoutput("grep -w PRETTY_NAME /etc/os-release | head -n1 | cut -d= -f2- | tr -d '\"'")
    ipsaya = subprocess.getoutput("curl -s ipv4.icanhazip.com")
    city = subprocess.getoutput("cat /etc/xray/city 2>/dev/null || echo '-'")
    domain = subprocess.getoutput("cat /etc/xray/domain 2>/dev/null || echo '-'")

    msg = f"""
╭━〔 🐾🕊️ PUBLIC PANEL MENU 🕊️🐾 〕
┃
┃  • CITY    : {city.strip()}
┃  • DOMAIN  : {domain.strip()}
┃  • IP VPS  : {ipsaya.strip()}
┃  • OS      : {namaos.strip()}
┃
┃━━━━━━━━〔 Total Account Created 〕
┃  🚀 SSH OVPN     : {ssh.strip()} account
┃  🎭 XRAY VMESS   : {vms.strip()} account
┃  🗼 XRAY VLESS   : {vls.strip()} account
┃  🎯 XRAY TROJAN  : {trj.strip()} account
┃
╰━━━━━━━━━━━━━━━━━━━━━━━╯
"""
    try:
        await event.edit(msg, buttons=inline)
    except:
        await event.reply(msg, buttons=inline)
