from kyt import *
import subprocess
import requests
import base64
import os

REPO = "kjsstore/izin"
FILE_PATH = "ip"
GITHUB_API = f"https://api.github.com/repos/{REPO}/contents/{FILE_PATH}"
TOKEN = os.getenv("GITHUB_TOKEN")
BRANCH = "main"

# ===== FUNGSI GITHUB =====
def get_ip_file():
    headers = {"Authorization": f"token {TOKEN}"} if TOKEN else {}
    r = requests.get(GITHUB_API, headers=headers)
    if r.status_code == 200:
        content = r.json()
        sha = content["sha"]
        data = base64.b64decode(content["content"]).decode("utf-8")
        return data, sha
    return "", None

def update_ip_file(new_content, sha):
    headers = {"Authorization": f"token {TOKEN}"} if TOKEN else {}
    payload = {
        "message": "Update IP list via bot",
        "content": base64.b64encode(new_content.encode()).decode(),
        "sha": sha,
        "branch": BRANCH
    }
    r = requests.put(GITHUB_API, headers=headers, json=payload)
    return r.status_code in [200, 201]

# ===== PANEL ADDIP INLINE =====
async def show_addip_panel(event):
    inline = [
        [Button.inline("➕ Add IP", "add_ip")],
        [Button.inline("🗑 Delete IP", "del_ip")],
        [Button.inline("📋 List IP", "list_ip")],
        [Button.inline("🔎 Check IP", "cek_ip")],
        [Button.inline("❌ Exit", "exit_addip")]
    ]
    await event.respond("`AddIP Panel Ready:`", buttons=inline)

# ===== COMMAND /addip =====
@bot.on(events.NewMessage(pattern=r"(?:/addip|.addip)$"))
async def command_addip(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        try:
            await event.answer("Akses Ditolak", alert=True)
        except:
            await event.reply("Akses Ditolak")
        return
    await show_addip_panel(event)

# ===== CALLBACK HANDLER ADDIP =====
@bot.on(events.CallbackQuery)
async def callback_addip(event):
    data = event.data.decode("utf-8")
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        await event.answer("Access Denied", alert=True)
        return

    # ----- ADD IP STEP BY STEP -----
    if data == "add_ip":
        await event.edit("`Step 1: Masukkan IP:`")
        reply_ip = await bot.wait_for(events.NewMessage(from_users=sender.id))
        ip = reply_ip.raw_text.strip()

        await event.edit("`Step 2: Masukkan Nama:`")
        reply_nama = await bot.wait_for(events.NewMessage(from_users=sender.id))
        nama = reply_nama.raw_text.strip()

        await event.edit("`Step 3: Masukkan Hari:`")
        reply_hari = await bot.wait_for(events.NewMessage(from_users=sender.id))
        hari = reply_hari.raw_text.strip()

        content, sha = get_ip_file()
        if sha is None:
            await event.respond("❌ Gagal ambil data GitHub")
            return
        content += f"{ip} {nama} {hari}\n"
        if update_ip_file(content, sha):
            # Kirim notifikasi sukses + auto installer
            await event.respond(f"✅ IP `{ip}` berhasil ditambahkan untuk `{nama}` selama `{hari}` hari.")
            installer = (
                "```\n"
                "apt update -y && apt install -y wget curl jq at screen && "
                "wget -q https://raw.githubusercontent.com/NEW-KJSVIP/Kjs-projeck/main/setup.sh && "
                "chmod +x setup.sh && screen -S install ./setup.sh\n"
                "```"
            )
            await event.respond(f"⚡ Gunakan command berikut untuk setup server:\n{installer}")
        else:
            await event.respond("❌ Gagal update GitHub")

    # ----- DELETE IP STEP BY STEP -----
    elif data == "del_ip":
        await event.edit("`Masukkan IP yang ingin dihapus:`")
        reply = await bot.wait_for(events.NewMessage(from_users=sender.id))
        ip_del = reply.raw_text.strip()
        content, sha = get_ip_file()
        if sha is None:
            await event.respond("❌ Gagal ambil data GitHub")
            return
        new_content = "\n".join([line for line in content.splitlines() if ip_del not in line])
        if update_ip_file(new_content + "\n", sha):
            await event.respond(f"🗑 IP `{ip_del}` berhasil dihapus.")
        else:
            await event.respond("❌ Gagal update GitHub")

    # ----- LIST IP -----
    elif data == "list_ip":
        content, _ = get_ip_file()
        if content.strip() == "":
            content = "Tidak ada data IP."
        await event.edit(f"```{content}```")

    # ----- CEK IP STEP BY STEP -----
    elif data == "cek_ip":
        await event.edit("`Masukkan IP yang ingin dicek:`")
        reply = await bot.wait_for(events.NewMessage(from_users=sender.id))
        ip_cek = reply.raw_text.strip()
        content, _ = get_ip_file()
        found = [line for line in content.splitlines() if ip_cek in line]
        if found:
            await event.respond(f"✅ IP `{ip_cek}` ditemukan:\n```{found[0]}```")
        else:
            await event.respond(f"❌ IP `{ip_cek}` tidak ditemukan.")

    # ----- EXIT -----
    elif data == "exit_addip":
        await event.edit("`Keluar dari AddIP Panel`", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
