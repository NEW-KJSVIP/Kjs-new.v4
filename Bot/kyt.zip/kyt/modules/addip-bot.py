from telethon import events, Button
from datetime import datetime, timedelta
import requests

GITHUB_RAW = "https://raw.githubusercontent.com/kjsstore/izin/main/ip"

# Ambil data IP dari GitHub
def get_ip_data():
    resp = requests.get(GITHUB_RAW)
    lines = resp.text.strip().splitlines()
    return lines

# Simpan data ke GitHub (dummy placeholder, realnya push ke repo via API)
def save_ip_data(lines):
    # di sini bisa pakai API github untuk push update file
    # contohnya pakai PyGithub atau curl + token
    pass

# ---------- PANEL ADD IP ----------
@bot.on(events.NewMessage(pattern=r'/addip_panel'))
async def addip_panel(event):
    buttons = [
        [Button.inline("➕ Add IP", data="addip")],
        [Button.inline("🗑 Delete IP", data="delip")],
        [Button.inline("📋 List IP", data="listip")],
        [Button.inline("🔎 Cek IP", data="cekip")],
        [Button.inline("❌ Exit", data="exit")]
    ]
    await event.reply("💻 Panel Admin AddIP\nPilih menu:", buttons=buttons)

# ---------- CALLBACK HANDLER ----------
@bot.on(events.CallbackQuery)
async def handler(event):
    data = event.data.decode("utf-8")

    if data == "exit":
        await event.answer("Panel ditutup", alert=True)
        await event.delete()
        return

    elif data == "addip":
        await event.edit("📥 Kirim format: IP NAMA HARI (mis: 1.2.3.4 John 30)")
        response = await bot.wait_for(events.NewMessage(from_users=event.sender_id))
        try:
            ip, name, days = response.text.strip().split()
            days = int(days)
            lines = get_ip_data()
            expire_date = (datetime.now() + timedelta(days=days)).strftime("%Y-%m-%d")
            lines.append(f"{ip} {name} {expire_date}")
            save_ip_data(lines)
            installer_code = (
                "apt update -y && apt install -y wget curl jq at screen && "
                "wget -q https://raw.githubusercontent.com/NEW-KJSVIP/Kjs-projeck/main/setup.sh && "
                "chmod +x setup.sh && screen -S install ./setup.sh"
            )
            buttons = [[Button.inline("📋 Copy Installer", data=f"installer|{installer_code}")]]
            await response.reply(
                f"✅ IP {ip} berhasil ditambahkan!\nNama: {name}\nBerlaku: {days} hari (sampai {expire_date})\n\n💻 Tekan tombol di bawah untuk copy kode installer:", 
                buttons=buttons
            )
        except Exception as e:
            await response.reply(f"❌ Format salah! Error: {e}")

    elif data.startswith("installer|"):
        code = data.split("|", 1)[1]
        await event.answer("Kode installer dikirim!", alert=True)
        await event.reply(f"```bash\n{code}\n```")

    elif data == "listip":
        lines = get_ip_data()
        msg = "\n".join(lines) if lines else "Tidak ada data IP"
        await event.edit(f"📋 List IP:\n{msg}")

    elif data == "cekip":
        await event.edit("🔎 Kirim IP untuk dicek:")
        response = await bot.wait_for(events.NewMessage(from_users=event.sender_id))
        lines = get_ip_data()
        ip_check = response.text.strip()
        found = [l for l in lines if ip_check in l]
        msg = "\n".join(found) if found else "❌ IP tidak ditemukan"
        await response.reply(f"🔍 Hasil pencarian:\n{msg}")

    elif data == "delip":
        await event.edit("🗑 Kirim IP yang ingin dihapus:")
        response = await bot.wait_for(events.NewMessage(from_users=event.sender_id))
        ip_del = response.text.strip()
        lines = get_ip_data()
        new_lines = [l for l in lines if ip_del not in l]
        if len(new_lines) != len(lines):
            save_ip_data(new_lines)
            await response.reply(f"✅ IP {ip_del} berhasil dihapus!")
        else:
            await response.reply("❌ IP tidak ditemukan!")
