from kyt import *
import subprocess

@bot.on(events.NewMessage(pattern=r"(?:.start|/start)$"))
@bot.on(events.CallbackQuery(data=b'start'))
async def start(event):
    inline = [
        [Button.inline("PANEL CREATE ACCOUNT","menu")],
        [Button.url("PRIVATE MESSAGE","https://t.me/newbie_store24"),
         Button.url("ORDER SCRIPT","https://whatsapp.nevpn.site")]
    ]
    sender = await event.get_sender()
    val = valid(str(sender.id))
    if val == "false":
        try:
            await event.answer("Akses Ditolak", alert=True)
        except:
            await event.reply("Akses Ditolak")
    elif val == "true":
        # Jumlah akun (pakai grep aman, fallback 0 kalau file kosong/ga ada)
        def count_file(path):
            try:
                return subprocess.getoutput(f"grep -c '###' {path}") or "0"
            except:
                return "0"

        ssh = count_file("/etc/ssh/.ssh.db")
        vms = count_file("/etc/vmess/.vmess.db")
        vls = count_file("/etc/vless/.vless.db")
        trj = count_file("/etc/trojan/.trojan.db")

        # Info sistem
        namaos = subprocess.getoutput("grep -w PRETTY_NAME /etc/os-release | head -n1 | cut -d= -f2- | tr -d '\"'") or "-"
        ipsaya = subprocess.getoutput("curl -s ipv4.icanhazip.com") or "-"
        domain = subprocess.getoutput("cat /etc/xray/domain 2>/dev/null") or "-"
        city = subprocess.getoutput("cat /etc/xray/city 2>/dev/null") or "-"

        # Fungsi cek status service lebih aman
        def status(service):
            cek = subprocess.getoutput(f"systemctl is-active {service} 2>/dev/null").strip()
            return "✅" if cek == "active" else "❌"

        # Pilih service SSH/Dropbear otomatis
        if "active" in subprocess.getoutput("systemctl is-active ssh 2>/dev/null"):
            st_ssh = status("ssh")
        elif "active" in subprocess.getoutput("systemctl is-active dropbear 2>/dev/null"):
            st_ssh = status("dropbear")
        else:
            st_ssh = "❌"

        st_xray = status("xray")
        st_nginx = status("nginx")
        st_haproxy = status("haproxy")

        msg = f"""```
╭━〔 🐾🕊️ PREMIUM PANEL 🕊️🐾 〕
┃
┃  • Status Server  : ✅ Online
┃  • DOMAIN         : {domain.strip()}
┃  • IP VPS         : {ipsaya.strip()}
┃  • OS             : {namaos.strip()}
┃  • CITY           : {city.strip()}
┃
┃━━━━━━〔 Statistik Akun 〕
┃  🚀 SSH OVPN    : {ssh}
┃  🎭 XRAY VMESS  : {vms}
┃  🗼 XRAY VLESS  : {vls}
┃  🎯 XRAY TROJAN : {trj}
┃
┃━━━━━━〔 Status Service 〕
┃  • SSH/Dropbear : {st_ssh}
┃  • XRAY         : {st_xray}
┃  • NGINX        : {st_nginx}
┃  • HAProxy      : {st_haproxy}
┃
┃━━━━━━〔 Informasi Penting 〕
┃  ⚠️ Gunakan akun sesuai aturan
┃  ⚠️ Backup config penting
┃  ⚠️ Add-on hanya dari panel resmi
┃
┃━━━━━━〔 Admin 〕
┃  @KJS_STORE
╰━━━━━━━━━━━━━━━━━╯
```"""
        try:
            await event.edit(msg, buttons=inline)
        except:
            await event.reply(msg, buttons=inline)
