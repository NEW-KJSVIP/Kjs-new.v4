banner = "https://files.catbox.moe/vl2fdm.jpeg"

    # Fungsi hitung baris akun
    def count_lines(filepath):
        try:
            with open(filepath, "r") as f:
                return sum(1 for line in f if "###" in line)
        except FileNotFoundError:
            return 0

    ssh = count_lines("/etc/ssh/.ssh.db")
    vms = count_lines("/etc/vmess/.vmess.db")
    vls = count_lines("/etc/vless/.vless.db")
    trj = count_lines("/etc/trojan/.trojan.db")

    namaos = platform.platform()
    try:
        with open("/etc/xray/city", "r") as f:
            city = f.read().strip()
    except FileNotFoundError:
        city = "Unknown"

    try:
        ipsaya = requests.get("https://ipv4.icanhazip.com", timeout=5).text.strip()
    except requests.RequestException:
        ipsaya = socket.gethostbyname(socket.gethostname())

    # =========================
    # ADMIN PANEL
    # =========================
    if user_id == ADMIN_ID:
        inline = [
            [Button.inline("PANEL CREATE ACCOUNT","menu")],
            [Button.url("🛒 HUBUNGI ADMIN", "https://wa.me/6285943111681")]
        ]

        msg = f"""
╭─〔 👑 OWNER PANEL 〕
│
│ 🆔 ID       : {user_id}
│ 👤 Name     : {firstname}
│ 📛 Username : {username if username else '-'}
│
├─〔 💻 Server Info 〕
│ 🖥️ OS       : {namaos.strip()}
│ 🌍 CITY     : {city.strip()}
│ 🌐 DOMAIN   : {DOMAIN}
│ 📡 IP VPS   : {ipsaya.strip()}
│
├─〔 📊 Jumlah Akun 〕
│ 🔑 SSH      : {ssh}
│ ⚡ VMESS    : {vms}
│ ✨ VLESS    : {vls}
│ 🔒 TROJAN   : {trj}
│
╰━━━━━━━━━━━━━━━━━━━━━━━
🚀 Powered by KJS-STORE™
"""
        await bot.send_file(event.chat_id, banner)
        await event.respond(msg, buttons=inline, link_preview=False)
    # =========================
    # USER PANEL
    # =========================
    else:
        inline = [
            [Button.inline("PANEL CREATE ACCOUNT","menu")],
            [Button.url("🛒 HUBUNGI ADMIN", "https://wa.me/6285943111681")]
        ]

        msg = f"""
╭─〔 👤 USER PANEL 〕
│
│ 🆔 ID       : {user_id}
│ 👤 Nama     : {firstname}
│ 📛 Username : {username if username else '-'}
│
├─〔 📊 Statistik Akun 〕
│ 🔑 SSH     : {ssh}
│ ⚡ VMESS   : {vms}
│ ✨ VLESS   : {vls}
│ 🔒 TROJAN  : {trj}
│
├─〔 ℹ️ Informasi Penting 〕
│ • Gunakan panel dengan bijak  
│ • Jangan disalahgunakan  
│ • Hubungi admin bila butuh bantuan
│
╰━━━━━━━━━━━━━━━━━━━━━━━
🚀 Powered by KJS-STORE™
"""
        await bot.send_file(event.chat_id, banner)
        await event.respond(msg, buttons=inline, link_preview=False)