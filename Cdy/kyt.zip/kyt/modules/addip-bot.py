from kyt import *
import subprocess
import time
import base64
import requests
import os

# ===== KONFIG =====
REPO = "kjsstore/izin"
FILE_PATH = "ip"
GITHUB_API = f"https://api.github.com/repos/{REPO}/contents/{FILE_PATH}"
TOKEN = os.getenv("GITHUB_TOKEN")  # simpan token di environment variable
BRANCH = "main"

# ===== FUNGSI BANTU =====
def get_ip_file():
    headers = {"Authorization": f"token {TOKEN}"}
    r = requests.get(GITHUB_API, headers=headers)
    if r.status_code == 200:
        content = r.json()
        sha = content["sha"]
        data = base64.b64decode(content["content"]).decode("utf-8")
        return data, sha
    return "", None

def update_ip_file(new_content, sha):
    headers = {"Authorization": f"token {TOKEN}"}
    payload = {
        "message": "Update IP list via bot",
        "content": base64.b64encode(new_content.encode()).decode(),
        "sha": sha,
        "branch": BRANCH
    }
    r = requests.put(GITHUB_API, headers=headers, json=payload)
    return r.status_code == 200 or r.status_code == 201

# ===== PANEL ADDIP =====
@bot.on(events.CallbackQuery(data=b'addip_panel'))
async def addip_panel(event):
    async def addip_panel_(event):
        await event.edit("`Loading AddIP Panel...`")
        time.sleep(1)
        buttons = [
            [Button.inline("➕ Add IP", "add_ip")],
            [Button.inline("🗑 Delete IP", "del_ip")],
            [Button.inline("📋 List IP", "list_ip")],
            [Button.inline("🔎 Check IP", "cek_ip")],
            [Button.inline("❌ Exit", "exit_addip")]
        ]
        await event.edit("`AddIP Panel Ready:`", buttons=buttons)

    sender = await event.get_sender()
    if valid(str(sender.id)) == "true":
        await addip_panel_(event)
    else:
        await event.answer("Access Denied", alert=True)

# ===== CALLBACK HANDLER =====
@bot.on(events.CallbackQuery)
async def callback_addip(event):
    data = event.data.decode("utf-8")

    # ===== ADD IP =====
    if data == "add_ip":
        await event.edit("`Masukkan IP, Nama, Hari (pisahkan spasi)`")
        reply = await bot.wait_for(events.NewMessage(from_users=event.sender_id))
        try:
            ip, nama, hari = reply.raw_text.split()
        except:
            await event.respond("Format salah! Contoh: `192.168.1.1 John 30`")
            return

        content, sha = get_ip_file()
        if sha is None:
            await event.respond("❌ Gagal ambil data GitHub")
            return

        content += f"{ip} {nama} {hari}\n"
        if update_ip_file(content, sha):
            await event.respond(f"✅ IP `{ip}` berhasil ditambahkan untuk `{nama}` selama `{hari}` hari.")
        else:
            await event.respond("❌ Gagal update GitHub")

    # ===== DELETE IP =====
    elif data == "del_ip":
        await event.edit("`Masukkan IP yang ingin dihapus:`")
        reply = await bot.wait_for(events.NewMessage(from_users=event.sender_id))
        ip_del = reply.raw_text.strip()

        content, sha = get_ip_file()
        if sha is None:
            await event.respond("❌ Gagal ambil data GitHub")
            return

        new_content = "\n".join([line for line in content.splitlines() if ip_del not in line])
        if update_ip_file(new_content + "\n", sha):
            await event.respond(f"🗑 IP `{ip_del}` berhasil dihapus.")
        else:
            await event.respond("❌ Gagal update GitHub")

    # ===== LIST IP =====
    elif data == "list_ip":
        content, _ = get_ip_file()
        if content.strip() == "":
            content = "Tidak ada data IP."
        await event.edit(f"```{content}```")

    # ===== CHECK IP =====
    elif data == "cek_ip":
        await event.edit("`Masukkan IP yang ingin dicek:`")
        reply = await bot.wait_for(events.NewMessage(from_users=event.sender_id))
        ip_cek = reply.raw_text.strip()
        content, _ = get_ip_file()
        found = [line for line in content.splitlines() if ip_cek in line]
        if found:
            await event.respond(f"✅ IP `{ip_cek}` ditemukan:\n```{found[0]}```")
        else:
            await event.respond(f"❌ IP `{ip_cek}` tidak ditemukan.")

    # ===== EXIT =====
    elif data == "exit_addip":
        await event.edit("`Keluar dari AddIP Panel`", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
